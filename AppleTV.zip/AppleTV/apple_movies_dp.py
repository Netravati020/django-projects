import xlrd as xlrd
import xlwt
from selenium import webdriver
from xlwt import Workbook
import time
import datetime
import openpyxl as op
import pandas as pd
import json
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.service import Service

# import requests
import re
from selenium.common.exceptions import NoSuchElementException
s = Service(r"C:\Users\BOT_MEDIA_VOD_1\PycharmProjects\pythonProject\Media_VOD\chromedriver.exe")
webdriver = webdriver.Chrome(service=s)

# webdriver = webdriver.Chrome(r'C:\Users\BOT_MEDIA_VOD_1\PycharmProjects\pythonProject\Media_VOD\chromedriver.exe')

Data = pd.read_excel(r'movie_links_jan_2024.xlsx')

df = pd.DataFrame(columns=['Content Type', 'Service', 'Country', 'Collection Date', 'Title', 'Year', 'Month',
                           'Day', 'Rating', 'Currency', 'Price SD Rent', 'Price SD Buy',
                           'Price HD Rent', 'Price HD Buy', 'Genre', 'Duration (minutes)', 'Network', 'Synopsis',
                           'Language', 'Production', 'Studio', 'Cast', 'Director', 'Writer', 'Format',
                           'URL'])

time.sleep(5)

for m in range(0, len(Data)):
    print(m)
    webdriver.get(Data.url[m])
    link = Data.url[m]
    time.sleep(5)

    try:

        soup = BeautifulSoup(webdriver.page_source, 'html.parser')
        all_elements = soup.find_all("script")
        data = json.loads(all_elements[1].contents[0])

        # time.sleep(5)

        # driver.find_element_by_css_selector('.button-blank.sign-in__close').click()
        # time.sleep(3)

        content = "Movie"
        service = "AppleTv+"
        country = "US"
        z = datetime.datetime.now()
        ab = str(z.strftime('%d'))
        bb = str(z.year)
        cb = str(z.strftime('%m'))
        collectiondate = cb + "/" + ab + "/" + bb
        title = ""
        year = ""
        synopsis = ""
        duration = ""
        month = ""
        genres = ""
        day = ""
        currency = ""
        sdrent = ""
        sdbuy = ""
        hdrent = ""
        hdbuy = ""
        language = ""
        studio = ""
        rating = ""
        mov_format = ""
        cast = ""
        director = ""
        production_company = ""
        writer = ""
        movie_url = link

        movie_dict = {'Content Type': 'Movie', 'Service': 'AppleTV+', 'Country': 'US',
                      'Collection Date': collectiondate,
                      'Title': '', 'Year': '', 'Month': '', 'Day': '', 'Rating': '', 'Currency': '',
                      'Price SD Rent': '',
                      'Price SD Buy': '', 'Price HD Rent': '', 'Price HD Buy': '', 'Genre': '',
                      'Duration (minutes)': '', 'Network': '',
                      'Synopsis': '', 'Language': '', 'Production': '', 'Studio': '', 'Cast': '', 'Director': '',
                      'Writer': '',
                      'Format': '', 'URL': movie_url}
        try:
            time.sleep(2)
            title = data['name']
        except:
            title = ''
            print("Title not available")

        movie_dict['Title'] = str(title)

        if webdriver.find_elements("xpath", "//dt[@class='typ-caption']")[0].text == 'Genre':
            genre = webdriver.find_elements("xpath",
                                            "//dd[@class='product-footer__metadata__section__desc typ-caption clr-secondary-text']")[
                0].text


            year = webdriver.find_elements("xpath","//dd[@class='product-footer__metadata__section__desc typ-caption clr-secondary-text']")[1].text


            duration = webdriver.find_elements("xpath","//dd[@class='product-footer__metadata__section__desc typ-caption clr-secondary-text']")[2].text


            rating = webdriver.find_elements("xpath","//dd[@class='product-footer__metadata__section__desc typ-caption clr-secondary-text']")[3].text


        else:
            # genre = webdriver.find_elements("xpath",
            #                                 "//dd[@class='product-footer__metadata__section__desc typ-caption clr-secondary-text']")[
            #     1].text
            genre= webdriver.find_element("xpath","//ul[@class='review-card__title--sub--list']/li").text
            print("genre",genre)

            year = webdriver.find_element("xpath", '//dt[text()="Released"]/following-sibling::dd[1]').text
            print("year",year)
            duration = webdriver.find_element("xpath", '//dt[text()="Run Time"]/following-sibling::dd[1]').text
            print("duration", duration)

            if 'hr' in duration:
                duration = duration.replace('hr', '').replace("min","").strip()
                print(duration)
                if ' ' in duration:
                    duration = duration.split('  ')
                    print(duration)
                    duration = int(duration[0]) * 60 + int(duration[1])
                    print(duration)

                else:
                    duration=duration.replace("min","")
                    duration = int(duration) * 60
                    print("duration:",duration)



            rating = webdriver.find_element("xpath","//dt[text()='Rated']/following-sibling::dd[1]").text
            print("rating", rating)
        movie_dict['Year'] = str(year)

        movie_dict['Duration (minutes)'] = duration

        movie_dict['Rating'] = str(rating)

        movie_dict['Genre'] = str(genre)

        try:
            synopsis = data['description']
        except:
            synopsis = ''
            print("Synopsis not available")

        movie_dict['Synopsis'] = str(synopsis)

        try:
            act = []
            for i in data['actor']:
                # print(i['name'])
                act.append(i['name'])
            cast = '|'.join(act)
            # cast = " | ".join(cas.split("\n"))
            print("cast:" , cast)
        except:
            cast = ''
            print("Cast not available")

        movie_dict['Cast'] = str(cast)

        try:
            dir = []
            for i in data['director']:
                print(i['name'])
                dir.append(i['name'])

            director = '|'.join(dir)
            print("director:",director)

        except:
            director = ''
            print("Director not available")

        movie_dict['Director'] = str(director)

        # if title == '':
        #     try:
        #         time.sleep(2)
        #         title = driver.find_element_by_xpath(
        #             '//*[@class="m-bottom10 m-left20 m-right20 ng-binding"]').text
        #     except:
        #         print("Title not available")

        time.sleep(2)

        df = pd.concat([df, pd.DataFrame([movie_dict])], ignore_index=True)
        df.to_excel(r'Appletv_Movies_testing.xlsx', sheet_name='Movies', index=False)


    except Exception as e:
        print(e)
        print("Exception in loading the movie " + str(link))
        time.sleep(2)

print("\n\n")
print('Done')