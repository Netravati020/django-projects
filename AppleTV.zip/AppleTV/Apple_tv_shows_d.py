import time
from selenium import webdriver
import pandas as pd
import datetime
from selenium.webdriver.chrome.service import Service

s = Service(r"C:\Users\BOT_MEDIA_VOD_1\PycharmProjects\pythonProject\Media_VOD\chromedriver.exe")
webdriver = webdriver.Chrome(service=s)

url = "https://www.google.com"
webdriver.get(url)

webdriver.maximize_window()

df_tvshows = pd.DataFrame(columns=['Content Type', 'Service', 'Country', 'Collection Date', 'Title',
                                   'Year', 'Month', 'Day', 'Season Number', 'Episode Number', 'Episode Name',
                                   'Number Episodes', 'Rating', 'Currency', 'Price SD Rent', 'Price SD Buy',
                                   'Price HD Rent', 'Price HD Buy', 'Genres', 'Duration (minutes)', 'Network',
                                   'Synopsis', 'Language', 'Production Company', 'Studio', 'Cast', 'Director',
                                   'Writer', 'Format', 'Season URL', 'Episode URL', 'Episode Synopsis'])



data = pd.read_excel(r"series_links_february_2024.xlsx")
# data= data[:4]
try:
    for l in range(0, len(data)):
        epsisode_name_unique = []
        print(l)
        webdriver.get(data.url[l])
        Url = data.url[l]

        time.sleep(10)

        title = webdriver.find_element("xpath", "//span[@class='visuallyhidden']").text.strip()
        print(title)
        if title=='':
            print('its not perfect url',Url)
            continue

        year = webdriver.find_elements("xpath","//div[@class='product-header__content__details__metadata--info']/span")[1].text
        print(year)
        try:
            cast = webdriver.find_element("xpath", "//span[@class='product-header__content__crews__list']").text
            print(cast)
        except:
            cast = ''
        # time.sleep(2)
        try:
            synopsis = webdriver.find_element("xpath","//div[@class='line-clamp  product-header__content__details__synopsis typography-title-3']").text
            print(synopsis)
        except:
            synopsis=''

        try:
            genere = webdriver.find_elements("xpath","//div[@class='product-header__content__details__metadata--info']/span")[0].text
            print(genere)
        except:
            genere = ''

        try:
            rating = webdriver.find_element("xpath","//span[contains(@class, 'badge badge--rating')]").get_attribute("aria-label").replace("Rated",'').strip()
            print(rating)
        except:
            rating = ''

        try:
            webdriver.execute_script("window.scrollTo(20, 550)")
            time.sleep(5)
        except:
            pass

        # check dropdown exist or not
        try:
            webdriver.find_element("xpath", '//div[@class="ember-basic-dropdown"]')
            dropdown_select = True
        except:
            dropdown_select = False

        if dropdown_select:
            # click dropdown
            webdriver.find_element("xpath", '//div[@class="ember-basic-dropdown"]').click()
            time.sleep(5)
            seasons = webdriver.find_elements("xpath",'//ul[@class="ember-power-select-options"]/li[@class="ember-power-select-option"]')
            webdriver.find_element("xpath", '//div[@class="ember-basic-dropdown"]').click()
            time.sleep(5)

            if len(seasons)>0:
                for g in range(0,len(seasons)):
                    webdriver.find_element("xpath", '//div[@class="ember-basic-dropdown"]').click()
                    time.sleep(5)
                    webdriver.find_elements("xpath",'//ul[@class="ember-power-select-options"]/li[@class="ember-power-select-option"]')[g].click()
                    time.sleep(8)
                    season_number = webdriver.find_element("xpath","//span[@class='ember-power-select-selected-item']").text.replace("Season","").strip()
                    print("season number",season_number)


                    try:
                        for i in range(0, 50):
                            webdriver.find_element("xpath","//button[@class='shelf-grid-nav__arrow shelf-grid-nav__arrow--next']").click()
                    except:
                        pass

                    episode_list = webdriver.find_elements("xpath", "//div[@class='episode-lockup__content']")
                    print("number of episode", len(episode_list))
                    epsisode_number_correct = []
                    for m in episode_list:
                        episode_number = m.find_element("xpath","./div[@class='clr-secondary-text text-truncate episode-lockup__content__episode-number']/span").text.replace("EPISODE","").strip()
                        episode_name = m.find_element("xpath","./div[@class='typ-subhead text-truncate episode-lockup__content__title']").text.strip()
                        year = webdriver.find_elements("xpath",
                                                       "//div[@class='product-header__content__details__metadata--info']/span")[1].text
                        print(year)
                        #check episode number not repeat again have or not for this season
                        if episode_number in epsisode_number_correct:
                            break

                        # check episode already have or not for this season
                        if episode_name in epsisode_name_unique:
                            continue
                        epsisode_name_unique.append(episode_name)
                        epsisode_number_correct.append(episode_number)

                        episode_synopsis = m.find_element("xpath","./p[@class='episode-lockup__description typ-caption clr-secondary-text']").text.strip()
                        duration =  m.find_element("xpath","./div[@class='episode-lockup__metadata clr-secondary-text text-truncate']/span").text.split("·")[0].replace("min","").strip()
                        print("duration:", duration)

                        if 'hr' in duration:
                            duration = duration.replace('hr', '').strip()
                            if ' ' in duration:
                                duration = duration.split()
                                duration = int(duration[0]) * 60 + int(duration[1])
                                print("duration:",duration)
                            else:
                                duration = int(duration) * 60
                                print("duration:",duration)


                        final_data2 = {'Content Type': 'Tv Show', 'Service': 'AppleTv+', 'Country': 'US',
                                       'Collection Date': datetime.date.today().strftime('%m/%d/%Y'), 'Title': title,
                                       'Year': year, 'Month': '', 'Day': '', 'Season Number': season_number,
                                       'Episode Number': episode_number, 'Episode Name': episode_name,
                                       'Number Episodes': '', 'Rating': rating, 'Currency': '', 'Price SD Rent': '',
                                       'Price SD Buy': '', 'Price HD Rent': '', 'Price HD Buy': '',
                                       'Genres': genere, 'Duration (minutes)': duration,
                                       'Network': '', 'Synopsis': synopsis, 'Language': '',
                                       'Production Company': '', 'Studio': '', 'Cast': cast, 'Director': '', 'Writer': '',
                                       'Format': '', 'Season URL': Url, 'Episode URL': '',
                                       'Episode Synopsis': episode_synopsis}
                        print(final_data2)
                        df_tvshows = pd.concat([df_tvshows, pd.DataFrame([final_data2])], ignore_index=True)
        else:
            season_number = webdriver.find_element("xpath", "//h2[@class='typ-headline-emph']").text.replace("Season","").strip()
            print("season number",season_number)
            year = webdriver.find_elements("xpath",
                                           "//div[@class='product-header__content__details__metadata--info']/span")[1].text
            print(year)
            try:
                for i in range(0, 10):
                    try:
                        webdriver.find_element("xpath","//button[@class='shelf-grid-nav__arrow shelf-grid-nav__arrow--next']").click()
                    except:
                        break
            except:
                pass
            episode_list = webdriver.find_elements("xpath", "//div[@class='episode-lockup__content']")
            print("number of episode",len(episode_list))
            for m in episode_list:
                episode_number = m.find_element("xpath","./div[@class='clr-secondary-text text-truncate episode-lockup__content__episode-number']/span").text.replace("EPISODE", "").strip()
                episode_name = m.find_element("xpath","./div[@class='typ-subhead text-truncate episode-lockup__content__title']").text.strip()
                print(episode_name)
                episode_synopsis = m.find_element("xpath","./p[@class='episode-lockup__description typ-caption clr-secondary-text']").text.strip()
                print(episode_synopsis)
                duration = m.find_element("xpath","./div[@class='episode-lockup__metadata clr-secondary-text text-truncate']/span").text.split("·")[0].replace("min", "").strip()
                print("duration:", duration)

                if 'hr' in duration:
                    duration = duration.replace('hr', '').strip()
                    # print(duration)
                    if ' ' in duration:
                        duration = duration.split()
                        duration = int(duration[0]) * 60 + int(duration[1])
                        print("duration:", duration)

                    else:
                        duration = int(duration) * 60
                        print("duration:", duration)

                final_data1 = {'Content Type': 'Tv Show', 'Service': 'AppleTv+', 'Country': 'US',
                               'Collection Date': datetime.date.today().strftime('%m/%d/%Y'), 'Title': title,
                               'Year': year, 'Month': '', 'Day': '', 'Season Number': season_number,
                               'Episode Number': episode_number, 'Episode Name': episode_name,
                               'Number Episodes': '', 'Rating': rating, 'Currency': '', 'Price SD Rent': '',
                               'Price SD Buy': '', 'Price HD Rent': '', 'Price HD Buy': '',
                               'Genres': genere, 'Duration (minutes)': duration,
                               'Network': '', 'Synopsis': synopsis, 'Language': '',
                               'Production Company': '', 'Studio': '', 'Cast': cast, 'Director': '', 'Writer': '',
                               'Format': '', 'Season URL': Url, 'Episode URL': '',
                               'Episode Synopsis': episode_synopsis}
                print(final_data1)
                df_tvshows = pd.concat([df_tvshows, pd.DataFrame([final_data1])], ignore_index=True)

        df_tvshows.to_excel('Apple_tv_tvshow_Data'+datetime.datetime.now().strftime('%B_%Y')+'.xlsx')
except:
    df_tvshows.to_excel('Apple_tv_tvshow_Data' + datetime.datetime.now().strftime('%B_%Y') + '.xlsx')

webdriver.close()