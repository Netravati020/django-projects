# url collection

import time
from selenium import webdriver
import pandas as pd
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
urls = [

    'https://tv.apple.com/us/room/feature-films/edt.item.6454f7d8-98d5-4c09-95a6-b4606de32cc2?ctx_brand=tvs.sbd.4000'
                ]
s = Service(r"C:\Users\BOT_MEDIA_VOD_1\PycharmProjects\pythonProject\Media_VOD\chromedriver.exe")

for url in urls:
    webdriver = webdriver.Chrome(service=s)
    webdriver.get(url)



links = []
time.sleep(5)
categories=[]

movie_links = []
series_links = []

for i in webdriver.find_elements("xpath","//div[@class='shelf-header--with-see-all']/a"):
   print(i.get_attribute('href'))
   categories.append(i.get_attribute('href'))

for i in range(0, len(categories)):
    webdriver.get(categories[i])
    time.sleep(5)
    print(i)
    for i in webdriver.find_elements("xpath", "//li[@class='collection-page__item']/div/a"):
        print(i.get_attribute('href'))
        if 'movie' in i.get_attribute('href'):
            movie_links.append(i.get_attribute('href'))
        elif 'show' in i.get_attribute('href'):
            series_links.append(i.get_attribute('href'))
        else:
            pass

df = pd.DataFrame()
df['url']=movie_links
df.to_excel(r'movie_links_jan_2024.xlsx')
print(len(df))
