# url collection

import time
from selenium import webdriver
import pandas as pd
from selenium.webdriver.chrome.service import Service

s = Service(r"C:\Users\BOT_MEDIA_VOD_1\PycharmProjects\pythonProject\Media_VOD\chromedriver.exe")
webdriver = webdriver.Chrome(service=s)

url = "https://www.google.com"
#https://tv.apple.com/us/room/feature-films/edt.item.6454f7d8-98d5-4c09-95a6-b4606de32cc2?ctx_brand=tvs.sbd.4000
webdriver.get('https://tv.apple.com')
# webdriver.get('https://tv.apple.com/us/collection/top-chart-tv-shows/uts.col.ChartsShows.tvs.sbd.4000?ctx_brand=tvs.sbd.4000&ctx_cvs=edt.cvs.610c550f-938a-46e7-98e3-c573fcd24208&ctx_shelf=edt.shelf.624ca2d2-0581-4c57-828c-2ae6e08956cd')
time.sleep(5)

links = []
time.sleep(10)
categories=[]

movie_links = []
series_links = []

# for i in webdriver.find_elements("xpath","//div[@class='shelf-header--with-see-all']/a"):
for i in webdriver.find_elements("xpath","//li[@class='shelf-grid__list-item']/div/a"):
   print(i.get_attribute('href'))
   categories.append(i.get_attribute('href'))

for i in range(0, len(categories)):
    webdriver.get(categories[i])
    time.sleep(5)
    print(i)
    # for i in webdriver.find_elements("xpath", "//li[@class='collection-page__item']/div/a"):
    for i in webdriver.find_elements("xpath","//div[@class='canvas-lockup']/a"):
        print(i.get_attribute('href'))
        scroll_step = 200
        initial_height = webdriver.execute_script("return document.body.scrollHeight")

        while True:
            webdriver.execute_script(f"window.scrollTo(0, window.scrollY + {scroll_step});")
            time.sleep(1)  # Adjust the sleep time as needed

            new_height = webdriver.execute_script("return document.body.scrollHeight")

            if new_height == initial_height:
                # Page has reached the bottom or has finished loading
                break

            # Update the initial height for the next iteration
            initial_height = new_height

        if 'movie' in i.get_attribute('href'):
            movie_links.append(i.get_attribute('href'))
        elif 'show' in i.get_attribute('href'):
            series_links.append(i.get_attribute('href'))
        else:
            pass

df = pd.DataFrame()
df['url']=movie_links

df1 = pd.DataFrame()
df1['url']=series_links
df1.to_excel(r'test_series_links_february_2024.xlsx')
df.to_excel(r'test_Movies_links_february_2024.xlsx')
